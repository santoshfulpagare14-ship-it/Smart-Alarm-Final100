package com.allminder.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "alarms")
data class Alarm(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "Alarm",
    val emoji: String = "⏰",
    val isPinned: Boolean = false,
    val isActive: Boolean = true,
    // HM: repeatValue = hours, repeatValue2 = minutes. Other units: repeatValue = every N
    val repeatValue: Int = 1,
    val repeatValue2: Int = 0,
    val repeatUnit: String = "HM", // HM, DAYS, WEEKS, MONTHS, YEARS
    val playOnHolidays: Boolean = true,
    val finishAfterValue: Int = 0, // 0 = never finish
    val finishAfterUnit: String = "DAYS", // DAYS, WEEKS, MONTHS
    val ringtoneUri: String = "",
    val vibrate: Boolean = true,
    val notify: Boolean = true,
    val volumeKeyAction: String = "MUTE", // MUTE, DISMISS, SNOOZE
    val lastSkippedAt: Long = 0
)

@Entity(
    tableName = "alarm_times",
    foreignKeys = [ForeignKey(
        entity = Alarm::class,
        parentColumns = ["id"],
        childColumns = ["alarmId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("alarmId")]
)
data class AlarmTime(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val alarmId: Long,
    val triggerAt: Long
)

@Entity(tableName = "holidays", indices = [Index(value = ["epochDay"], unique = true)])
data class Holiday(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val epochDay: Long
)

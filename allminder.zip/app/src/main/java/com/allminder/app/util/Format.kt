package com.allminder.app.util

import com.allminder.app.data.Alarm
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

val dateFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("EEE, dd MMM yyyy")
val timeFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("hh:mm a")

fun formatClock(ms: Long): String =
    Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(timeFmt)

fun formatNext(ms: Long?): String {
    if (ms == null) return "No upcoming alarm"
    val zone = ZoneId.systemDefault()
    val dt = Instant.ofEpochMilli(ms).atZone(zone)
    val today = LocalDate.now(zone)
    val d = dt.toLocalDate()
    val day = when (d) {
        today -> "today"
        today.plusDays(1) -> "tomorrow"
        else -> dt.format(DateTimeFormatter.ofPattern("EEE, dd MMM"))
    }
    return "Next, $day ${dt.format(timeFmt)}"
}

fun repeatSummary(a: Alarm): String = when (a.repeatUnit) {
    "HM" ->
        if (a.repeatValue == 0 && a.repeatValue2 == 0) "No repeat"
        else "every ${a.repeatValue} hours ${a.repeatValue2} minutes"
    "DAYS" -> if (a.repeatValue <= 0) "No repeat" else "every ${a.repeatValue} days"
    "WEEKS" -> if (a.repeatValue <= 0) "No repeat" else "every ${a.repeatValue} weeks"
    "MONTHS" -> if (a.repeatValue <= 0) "No repeat" else "every ${a.repeatValue} months"
    "YEARS" -> if (a.repeatValue <= 0) "No repeat" else "every ${a.repeatValue} years"
    else -> "No repeat"
}

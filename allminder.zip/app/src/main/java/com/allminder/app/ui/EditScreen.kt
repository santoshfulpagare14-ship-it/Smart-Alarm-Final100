package com.allminder.app.ui

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.allminder.app.data.Alarm
import com.allminder.app.util.dateFmt
import com.allminder.app.util.timeFmt
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

private val EMOJIS = listOf("⏰", "💧", "📌", "💊", "🍽️", "🏃", "📞", "📚", "🧘", "🚗", "💼", "🔔")

private val UNITS = listOf(
    "HM" to "Hours:Minutes",
    "DAYS" to "Days",
    "WEEKS" to "Weekly",
    "MONTHS" to "Month(s)",
    "YEARS" to "Years"
)

private val FINISH_UNITS = listOf("DAYS" to "Days", "WEEKS" to "Weeks", "MONTHS" to "Months")

private fun withDate(ms: Long, y: Int, m: Int, d: Int, zone: ZoneId): Long {
    val t: LocalTime = Instant.ofEpochMilli(ms).atZone(zone).toLocalTime()
    return LocalDateTime.of(LocalDate.of(y, m, d), t).atZone(zone).toInstant().toEpochMilli()
}

private fun withTime(ms: Long, h: Int, min: Int, zone: ZoneId): Long {
    val d: LocalDate = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()
    return LocalDateTime.of(d, LocalTime.of(h, min)).atZone(zone).toInstant().toEpochMilli()
}

private fun defaultTime(zone: ZoneId): Long =
    ZonedDateTime.now(zone).plusMinutes(5).withSecond(0).withNano(0).toInstant().toEpochMilli()

@Suppress("DEPRECATION")
private fun pickedUri(i: Intent?): Uri? =
    if (Build.VERSION.SDK_INT >= 33) {
        i?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
    } else {
        i?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
    }

private fun ringtoneName(ctx: Context, uri: String): String {
    if (uri.isBlank()) return "Default alarm sound"
    return try {
        RingtoneManager.getRingtone(ctx, Uri.parse(uri))?.getTitle(ctx) ?: "Custom sound"
    } catch (e: Exception) {
        "Custom sound"
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 20.dp, bottom = 8.dp)
    )
}

@Composable
private fun DropdownField(current: String, options: List<Pair<String, String>>, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }) {
            Text(options.firstOrNull { it.first == current }?.second ?: current)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (k, l) ->
                DropdownMenuItem(text = { Text(l) }, onClick = { onSelect(k); open = false })
            }
        }
    }
}

@Composable
private fun NumField(value: String, label: String, modifier: Modifier = Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter { c -> c.isDigit() }.take(4)) },
        modifier = modifier,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        label = { Text(label) }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditScreen(vm: MainViewModel, alarmId: Long, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val zone = remember { ZoneId.systemDefault() }

    var active by remember { mutableStateOf(true) }
    var title by remember { mutableStateOf("") }
    var emoji by remember { mutableStateOf("⏰") }
    var pinned by remember { mutableStateOf(false) }
    val times = remember { mutableStateListOf<Long>() }
    var unit by remember { mutableStateOf("HM") }
    var v1 by remember { mutableStateOf("1") }
    var v2 by remember { mutableStateOf("0") }
    var playHolidays by remember { mutableStateOf(true) }
    var finishOn by remember { mutableStateOf(false) }
    var finishV by remember { mutableStateOf("1") }
    var finishUnit by remember { mutableStateOf("DAYS") }
    var ringtone by remember { mutableStateOf("") }
    var vibrate by remember { mutableStateOf(true) }
    var notify by remember { mutableStateOf(true) }
    var volAction by remember { mutableStateOf("MUTE") }
    var soundOpen by remember { mutableStateOf(false) }
    var lastSkipped by remember { mutableStateOf(0L) }

    LaunchedEffect(alarmId) {
        if (alarmId > 0L) {
            val r = vm.load(alarmId)
            if (r != null) {
                val a = r.first
                active = a.isActive
                title = a.title
                emoji = a.emoji
                pinned = a.isPinned
                unit = a.repeatUnit
                v1 = a.repeatValue.toString()
                v2 = a.repeatValue2.toString()
                playHolidays = a.playOnHolidays
                finishOn = a.finishAfterValue > 0
                finishV = if (a.finishAfterValue > 0) a.finishAfterValue.toString() else "1"
                finishUnit = a.finishAfterUnit
                ringtone = a.ringtoneUri
                vibrate = a.vibrate
                notify = a.notify
                volAction = a.volumeKeyAction
                lastSkipped = a.lastSkippedAt
                times.clear()
                times.addAll(r.second)
            }
        }
        if (times.isEmpty()) times.add(defaultTime(zone))
    }

    val pickRingtone = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uri = pickedUri(r.data)
        if (r.resultCode == Activity.RESULT_OK && uri != null) ringtone = uri.toString()
    }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // ignore
            }
            ringtone = uri.toString()
        }
    }
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && text != null) title = text
    }

    fun save() {
        if (times.isEmpty()) {
            Toast.makeText(ctx, "Add at least one time", Toast.LENGTH_SHORT).show()
            return
        }
        val a = Alarm(
            id = alarmId,
            title = title.trim().ifBlank { "Alarm" },
            emoji = emoji,
            isPinned = pinned,
            isActive = active,
            repeatValue = v1.toIntOrNull() ?: 0,
            repeatValue2 = if (unit == "HM") (v2.toIntOrNull() ?: 0) else 0,
            repeatUnit = unit,
            playOnHolidays = playHolidays,
            finishAfterValue = if (finishOn) (finishV.toIntOrNull() ?: 1).coerceAtLeast(1) else 0,
            finishAfterUnit = finishUnit,
            ringtoneUri = ringtone,
            vibrate = vibrate,
            notify = notify,
            volumeKeyAction = volAction,
            lastSkippedAt = lastSkipped
        )
        vm.save(a, times.toList()) { onClose() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (alarmId == 0L) "New alarm" else "Edit alarm") },
                navigationIcon = {
                    IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                actions = {
                    if (alarmId > 0L) {
                        IconButton(onClick = { vm.delete(alarmId) { onClose() } }) {
                            Icon(Icons.Filled.Delete, "Delete")
                        }
                    }
                    IconButton(onClick = { save() }) { Icon(Icons.Filled.Check, "Save") }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Active
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Alarm active", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                Switch(checked = active, onCheckedChange = { active = it })
            }

            // Title
            SectionTitle("Title")
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    label = { Text("e.g. Drink water") },
                    trailingIcon = {
                        IconButton(onClick = {
                            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            try {
                                voice.launch(i)
                            } catch (e: Exception) {
                                Toast.makeText(ctx, "Voice input not available", Toast.LENGTH_SHORT).show()
                            }
                        }) { Icon(Icons.Filled.Mic, "Voice input") }
                    }
                )
                IconToggleButton(checked = pinned, onCheckedChange = { pinned = it }) {
                    Icon(
                        Icons.Filled.PushPin, "Pin",
                        tint = if (pinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                    )
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp)) {
                EMOJIS.forEach { e ->
                    Text(
                        e,
                        fontSize = 26.sp,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (e == emoji) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                            .clickable { emoji = e }
                            .padding(8.dp)
                    )
                }
            }

            // Day and time
            SectionTitle("Day and Time")
            times.forEachIndexed { i, ms ->
                val dt = Instant.ofEpochMilli(ms).atZone(zone)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = {
                            DatePickerDialog(
                                ctx,
                                { _, y, m, d -> times[i] = withDate(ms, y, m + 1, d, zone) },
                                dt.year, dt.monthValue - 1, dt.dayOfMonth
                            ).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(dt.format(dateFmt)) }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = {
                        TimePickerDialog(
                            ctx,
                            { _, h, min -> times[i] = withTime(ms, h, min, zone) },
                            dt.hour, dt.minute, false
                        ).show()
                    }) { Text(dt.format(timeFmt)) }
                    IconButton(onClick = { if (times.size > 1) times.removeAt(i) }) {
                        Icon(Icons.Filled.RemoveCircleOutline, "Remove time")
                    }
                }
            }
            TextButton(onClick = { times.add(defaultTime(zone)) }) {
                Icon(Icons.Filled.AddCircleOutline, null)
                Spacer(Modifier.width(8.dp))
                Text("Add another time")
            }

            // Repeat
            SectionTitle("Repeat?")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Every", Modifier.padding(end = 8.dp))
                NumField(v1, if (unit == "HM") "Hours" else "N", Modifier.width(88.dp)) { v1 = it }
                if (unit == "HM") {
                    Text(" : ", Modifier.padding(horizontal = 4.dp))
                    NumField(v2, "Minutes", Modifier.width(96.dp)) { v2 = it }
                }
                Spacer(Modifier.width(8.dp))
                DropdownField(unit, UNITS) { unit = it }
            }
            Text(
                "Set 0 to ring only once.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 4.dp)
            )

            // Holidays
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                Checkbox(checked = playHolidays, onCheckedChange = { playHolidays = it })
                Text("Play on holidays")
            }

            // Finish
            SectionTitle("Finish?")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = finishOn, onCheckedChange = { finishOn = it })
                Text("After")
                Spacer(Modifier.width(8.dp))
                NumField(finishV, "N", Modifier.width(88.dp)) { finishV = it }
                Spacer(Modifier.width(8.dp))
                DropdownField(finishUnit, FINISH_UNITS) { finishUnit = it }
            }
            if (!finishOn) {
                Text("Never (keeps repeating)", style = MaterialTheme.typography.bodySmall)
            }

            HorizontalDivider(Modifier.padding(top = 20.dp))

            // Sound and notification
            Row(
                Modifier.fillMaxWidth().clickable { soundOpen = !soundOpen }.padding(vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Sound and Notification", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                Icon(if (soundOpen) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, null)
            }
            if (soundOpen) {
                val rName = remember(ringtone) { ringtoneName(ctx, ringtone) }
                Text("Ringtone: $rName", style = MaterialTheme.typography.bodyMedium)
                Row(Modifier.padding(vertical = 4.dp)) {
                    OutlinedButton(onClick = {
                        val existing = if (ringtone.isBlank()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                        else Uri.parse(ringtone)
                        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, existing)
                        try {
                            pickRingtone.launch(i)
                        } catch (e: Exception) {
                            Toast.makeText(ctx, "Ringtone picker not available", Toast.LENGTH_SHORT).show()
                        }
                    }) { Text("Ringtones") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { pickFile.launch(arrayOf("audio/*")) }) { Text("Choose file") }
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { ringtone = "" }) { Text("Default") }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Vibration", Modifier.weight(1f))
                    Switch(checked = vibrate, onCheckedChange = { vibrate = it })
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Full-screen alarm notification", Modifier.weight(1f))
                    Switch(checked = notify, onCheckedChange = { notify = it })
                }
            }

            HorizontalDivider()

            // Volume keys
            SectionTitle("Volume Keys Action")
            listOf(
                "MUTE" to "Mute / Skip this ring (repeat continues)",
                "DISMISS" to "Dismiss (turn the alarm off)",
                "SNOOZE" to "Snooze 5 minutes"
            ).forEach { (k, l) ->
                Row(
                    Modifier.fillMaxWidth().clickable { volAction = k },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = volAction == k, onClick = { volAction = k })
                    Text(l)
                }
            }

            // Smart actions
            SectionTitle("Smart actions")
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Coming soon", Modifier.weight(1f), color = MaterialTheme.colorScheme.outline)
                Switch(checked = false, onCheckedChange = null, enabled = false)
            }

            Spacer(Modifier.height(48.dp))
        }
    }
}

package com.allminder.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.allminder.app.data.Alarm
import com.allminder.app.data.AlarmTime
import com.allminder.app.data.AppDatabase
import com.allminder.app.data.Holiday
import com.allminder.app.scheduler.Scheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val dao = AppDatabase.get(ctx).dao()

    val alarms = dao.observeAlarms()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val times = dao.observeTimes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val holidays = dao.observeHolidays()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun toggle(id: Long, on: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.setActive(id, on)
            Scheduler.scheduleOne(ctx, id)
        }
    }

    fun delete(id: Long, done: () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            Scheduler.cancel(ctx, id)
            dao.deleteAlarm(id)
            withContext(Dispatchers.Main) { done() }
        }
    }

    suspend fun load(id: Long): Pair<Alarm, List<Long>>? = withContext(Dispatchers.IO) {
        val a = dao.getAlarm(id)
        if (a == null) null else Pair(a, dao.getTimes(id).map { it.triggerAt })
    }

    fun save(a: Alarm, timesList: List<Long>, done: () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val id: Long
            if (a.id == 0L) {
                id = dao.insertAlarm(a)
            } else {
                dao.updateAlarm(a)
                id = a.id
            }
            dao.deleteTimes(id)
            dao.insertTimes(timesList.map { AlarmTime(alarmId = id, triggerAt = it) })
            Scheduler.scheduleOne(ctx, id)
            withContext(Dispatchers.Main) { done() }
        }
    }

    fun addHoliday(epochDay: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.insertHoliday(Holiday(epochDay = epochDay))
            Scheduler.rescheduleAll(ctx)
        }
    }

    fun removeHoliday(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.deleteHoliday(id)
            Scheduler.rescheduleAll(ctx)
        }
    }
}

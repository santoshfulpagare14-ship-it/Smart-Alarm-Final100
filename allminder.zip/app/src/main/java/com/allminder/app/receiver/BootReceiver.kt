package com.allminder.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.allminder.app.scheduler.Scheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                Scheduler.rescheduleAll(app)
            } finally {
                pending.finish()
            }
        }
    }
}

package com.allminder.app.scheduler

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.allminder.app.MainActivity
import com.allminder.app.data.Alarm
import com.allminder.app.data.AlarmDao
import com.allminder.app.data.AlarmTime
import com.allminder.app.data.AppDatabase
import com.allminder.app.receiver.AlarmReceiver
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit

object Scheduler {
    const val ACTION_TRIGGER = "com.allminder.app.TRIGGER"
    const val EXTRA_ID = "alarmId"
    const val EXTRA_SNOOZE = "snooze"

    private fun repeatStep(a: Alarm): Pair<ChronoUnit, Long>? {
        val v = a.repeatValue.toLong()
        return when (a.repeatUnit) {
            "HM" -> {
                val m = v * 60L + a.repeatValue2.toLong()
                if (m > 0L) Pair(ChronoUnit.MINUTES, m) else null
            }
            "DAYS" -> if (v > 0L) Pair(ChronoUnit.DAYS, v) else null
            "WEEKS" -> if (v > 0L) Pair(ChronoUnit.WEEKS, v) else null
            "MONTHS" -> if (v > 0L) Pair(ChronoUnit.MONTHS, v) else null
            "YEARS" -> if (v > 0L) Pair(ChronoUnit.YEARS, v) else null
            else -> null
        }
    }

    private fun finishUnit(a: Alarm): ChronoUnit = when (a.finishAfterUnit) {
        "WEEKS" -> ChronoUnit.WEEKS
        "MONTHS" -> ChronoUnit.MONTHS
        else -> ChronoUnit.DAYS
    }

    private fun nextFrom(start: ZonedDateTime, after: ZonedDateTime, unit: ChronoUnit, step: Long): ZonedDateTime {
        if (start.isAfter(after)) return start
        var n = unit.between(start, after) / step
        var c = start.plus(n * step, unit)
        while (!c.isAfter(after)) {
            n++
            c = start.plus(n * step, unit)
        }
        return c
    }

    private fun firstValid(
        a: Alarm,
        start: ZonedDateTime,
        after: ZonedDateTime,
        end: ZonedDateTime?,
        holidays: Set<LocalDate>
    ): ZonedDateTime? {
        val step = repeatStep(a)
        var cursor = after
        for (i in 0 until 3000) {
            val cand: ZonedDateTime = if (step == null) {
                if (start.isAfter(cursor)) start else return null
            } else {
                nextFrom(start, cursor, step.first, step.second)
            }
            if (end != null && cand.isAfter(end)) return null
            if (a.playOnHolidays || cand.toLocalDate() !in holidays) return cand
            cursor = cand
        }
        return null
    }

    /** Next moment (epoch millis) strictly after [afterMillis] this alarm should ring, or null. */
    fun nextOccurrence(a: Alarm, times: List<AlarmTime>, holidays: Set<LocalDate>, afterMillis: Long): Long? {
        val zone = ZoneId.systemDefault()
        val now = Instant.ofEpochMilli(afterMillis).atZone(zone)
        var best: Long? = null
        for (t in times) {
            val start = Instant.ofEpochMilli(t.triggerAt).atZone(zone)
            val end = if (a.finishAfterValue > 0) start.plus(a.finishAfterValue.toLong(), finishUnit(a)) else null
            val c = firstValid(a, start, now, end, holidays) ?: continue
            val ms = c.toInstant().toEpochMilli()
            if (best == null || ms < best) best = ms
        }
        return best
    }

    suspend fun holidaySet(dao: AlarmDao): Set<LocalDate> =
        dao.getHolidays().map { LocalDate.ofEpochDay(it.epochDay) }.toSet()

    private fun pending(ctx: Context, id: Long, snooze: Boolean): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .setAction(ACTION_TRIGGER)
            .putExtra(EXTRA_ID, id)
            .putExtra(EXTRA_SNOOZE, snooze)
        val code = if (snooze) (id + 1_000_000L).toInt() else id.toInt()
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun showIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    /** Schedules the next occurrence. Returns its time, or null if nothing is left. */
    fun schedule(ctx: Context, a: Alarm, times: List<AlarmTime>, holidays: Set<LocalDate>): Long? {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(pending(ctx, a.id, false))
        if (!a.isActive) return null
        val next = nextOccurrence(a, times, holidays, System.currentTimeMillis()) ?: return null
        am.setAlarmClock(AlarmManager.AlarmClockInfo(next, showIntent(ctx)), pending(ctx, a.id, false))
        return next
    }

    fun scheduleSnooze(ctx: Context, id: Long, minutes: Int) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val at = System.currentTimeMillis() + minutes * 60_000L
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, showIntent(ctx)), pending(ctx, id, true))
    }

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(pending(ctx, id, false))
        am.cancel(pending(ctx, id, true))
    }

    suspend fun scheduleOne(ctx: Context, id: Long) {
        val dao = AppDatabase.get(ctx).dao()
        val a = dao.getAlarm(id)
        if (a == null) {
            cancel(ctx, id)
            return
        }
        schedule(ctx, a, dao.getTimes(id), holidaySet(dao))
    }

    suspend fun rescheduleAll(ctx: Context) {
        val dao = AppDatabase.get(ctx).dao()
        val hol = holidaySet(dao)
        for (a in dao.getActiveAlarms()) {
            schedule(ctx, a, dao.getTimes(a.id), hol)
        }
    }
}

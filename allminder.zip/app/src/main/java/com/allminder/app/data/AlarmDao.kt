package com.allminder.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AlarmDao {
    @Query("SELECT * FROM alarms")
    fun observeAlarms(): Flow<List<Alarm>>

    @Query("SELECT * FROM alarm_times")
    fun observeTimes(): Flow<List<AlarmTime>>

    @Query("SELECT * FROM holidays ORDER BY epochDay")
    fun observeHolidays(): Flow<List<Holiday>>

    @Query("SELECT * FROM alarms WHERE id = :id")
    suspend fun getAlarm(id: Long): Alarm?

    @Query("SELECT * FROM alarm_times WHERE alarmId = :id ORDER BY triggerAt")
    suspend fun getTimes(id: Long): List<AlarmTime>

    @Query("SELECT * FROM alarms WHERE isActive = 1")
    suspend fun getActiveAlarms(): List<Alarm>

    @Query("SELECT * FROM holidays")
    suspend fun getHolidays(): List<Holiday>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlarm(alarm: Alarm): Long

    @Update
    suspend fun updateAlarm(alarm: Alarm)

    @Query("DELETE FROM alarms WHERE id = :id")
    suspend fun deleteAlarm(id: Long)

    @Insert
    suspend fun insertTimes(times: List<AlarmTime>)

    @Query("DELETE FROM alarm_times WHERE alarmId = :id")
    suspend fun deleteTimes(id: Long)

    @Query("UPDATE alarms SET isActive = :active WHERE id = :id")
    suspend fun setActive(id: Long, active: Boolean)

    @Query("UPDATE alarms SET lastSkippedAt = :time WHERE id = :id")
    suspend fun setSkipped(id: Long, time: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertHoliday(holiday: Holiday)

    @Query("DELETE FROM holidays WHERE id = :id")
    suspend fun deleteHoliday(id: Long)
}

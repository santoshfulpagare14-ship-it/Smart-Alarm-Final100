package com.allminder.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.VolumeProvider
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.allminder.app.R
import com.allminder.app.data.Alarm
import com.allminder.app.data.AppDatabase
import com.allminder.app.scheduler.Scheduler
import com.allminder.app.ui.RingingActivity
import com.allminder.app.util.formatClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class AlarmService : Service() {

    companion object {
        const val ACTION_START = "com.allminder.app.START"
        const val ACTION_MUTE = "com.allminder.app.MUTE"
        const val ACTION_SNOOZE = "com.allminder.app.SNOOZE"
        const val ACTION_DISMISS = "com.allminder.app.DISMISS"
        const val ACTION_VOLKEY = "com.allminder.app.VOLKEY"
        const val ACTION_CLOSE_UI = "com.allminder.app.CLOSE_UI"
        const val EXTRA_ID = "alarmId"
        const val SNOOZE_MIN = 5
        private const val CHANNEL = "allminder_ringing"
        private const val NOTIF_ID = 4242

        fun intent(ctx: Context, id: Long, action: String): Intent =
            Intent(ctx, AlarmService::class.java).setAction(action).putExtra(EXTRA_ID, id)
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var session: MediaSession? = null
    private var alarm: Alarm? = null
    private var alarmId = -1L

    @Volatile
    private var ringing = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getLongExtra(EXTRA_ID, -1L) ?: -1L
        when (intent?.action) {
            ACTION_START -> start(id)
            ACTION_MUTE -> end("MUTE")
            ACTION_SNOOZE -> end("SNOOZE")
            ACTION_DISMISS -> end("DISMISS")
            ACTION_VOLKEY -> end(alarm?.volumeKeyAction ?: "MUTE")
            else -> if (!ringing) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun start(id: Long) {
        if (ringing) stopSound()
        alarmId = id
        alarm = null
        ringing = true
        ensureChannel()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(null), type)

        scope.launch {
            val a = AppDatabase.get(applicationContext).dao().getAlarm(id)
            main.post {
                if (!ringing || alarmId != id) return@post
                alarm = a
                getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(a))
                startSound(a)
                registerVolumeKeys()
            }
        }
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Alarm ringing", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.setBypassDnd(true)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun svc(action: String): PendingIntent =
        PendingIntent.getService(
            this, action.hashCode(), intent(this, alarmId, action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun buildNotification(a: Alarm?): Notification {
        val ui = PendingIntent.getActivity(
            this, 0,
            Intent(this, RingingActivity::class.java)
                .putExtra(EXTRA_ID, alarmId)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_bell)
            .setContentTitle(if (a != null) "${a.emoji} ${a.title}" else "Alarm")
            .setContentText("Alarm ringing")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setContentIntent(ui)
            .addAction(0, "Snooze", svc(ACTION_SNOOZE))
            .addAction(0, "Stop", svc(ACTION_MUTE))
        if (a == null || a.notify) b.setFullScreenIntent(ui, true)
        return b.build()
    }

    private fun startSound(a: Alarm?) {
        val custom: Uri? = if (a != null && a.ringtoneUri.isNotBlank()) Uri.parse(a.ringtoneUri) else null
        val fallback: Uri? = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        if (!play(custom)) play(fallback)

        if (a == null || a.vibrate) {
            val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(VibratorManager::class.java).defaultVibrator
            } else {
                getSystemService(Vibrator::class.java)
            }
            vibrator = v
            v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 600), 0))
        }
    }

    private fun play(uri: Uri?): Boolean {
        if (uri == null) return false
        return try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Lets the hardware volume keys mute the alarm even when the screen is off (best effort). */
    private fun registerVolumeKeys() {
        try {
            val s = MediaSession(this, "AllminderRing")
            s.setPlaybackState(
                PlaybackState.Builder()
                    .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
                    .build()
            )
            s.setPlaybackToRemote(object : VolumeProvider(VolumeProvider.VOLUME_CONTROL_RELATIVE, 100, 50) {
                override fun onAdjustVolume(direction: Int) {
                    if (direction != 0) main.post { end(alarm?.volumeKeyAction ?: "MUTE") }
                }
            })
            s.isActive = true
            session = s
        } catch (e: Exception) {
            // ignore: the ringing screen still handles the keys
        }
    }

    private fun stopSound() {
        try {
            player?.stop()
        } catch (e: Exception) {
            // ignore
        }
        player?.release()
        player = null
        vibrator?.cancel()
        vibrator = null
        try {
            session?.release()
        } catch (e: Exception) {
            // ignore
        }
        session = null
    }

    private fun end(kind: String) {
        if (!ringing) {
            stopSelf()
            return
        }
        ringing = false
        stopSound()
        val id = alarmId
        sendBroadcast(Intent(ACTION_CLOSE_UI).setPackage(packageName))
        scope.launch {
            val ctx = applicationContext
            val dao = AppDatabase.get(ctx).dao()
            val msg: String
            when (kind) {
                "SNOOZE" -> {
                    Scheduler.scheduleSnooze(ctx, id, SNOOZE_MIN)
                    msg = "Snoozed for $SNOOZE_MIN min"
                }
                "DISMISS" -> {
                    dao.setActive(id, false)
                    Scheduler.cancel(ctx, id)
                    msg = "Alarm turned off"
                }
                else -> {
                    // Mute only this ring. The next repeat is already scheduled and is NOT touched.
                    dao.setSkipped(id, System.currentTimeMillis())
                    val a = dao.getAlarm(id)
                    val next = if (a != null) {
                        Scheduler.nextOccurrence(a, dao.getTimes(id), Scheduler.holidaySet(dao), System.currentTimeMillis())
                    } else null
                    msg = if (next != null) "Muted! Next alarm at ${formatClock(next)}" else "Muted!"
                }
            }
            main.post {
                Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                if (!ringing) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }
    }

    override fun onDestroy() {
        stopSound()
        scope.cancel()
        super.onDestroy()
    }
}

package com.allminder.app.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.allminder.app.data.Alarm
import com.allminder.app.data.AppDatabase
import com.allminder.app.service.AlarmService
import com.allminder.app.ui.theme.AllminderTheme
import com.allminder.app.util.formatClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class RingingActivity : ComponentActivity() {

    private var alarmId = -1L

    private val closeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ContextCompat.registerReceiver(
            this, closeReceiver, IntentFilter(AlarmService.ACTION_CLOSE_UI),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        alarmId = intent.getLongExtra(AlarmService.EXTRA_ID, -1L)
        setContent {
            AllminderTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    RingingScreen(alarmId) { send(it) }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        recreate()
    }

    private fun send(action: String) {
        startService(AlarmService.intent(this, alarmId, action))
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event?.repeatCount == 0) send(AlarmService.ACTION_VOLKEY)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) return true
        return super.onKeyUp(keyCode, event)
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(closeReceiver)
        } catch (e: Exception) {
            // ignore
        }
        super.onDestroy()
    }
}

@Composable
private fun RingingScreen(alarmId: Long, onAction: (String) -> Unit) {
    val ctx = LocalContext.current
    var alarm by remember { mutableStateOf<Alarm?>(null) }
    LaunchedEffect(alarmId) {
        alarm = withContext(Dispatchers.IO) { AppDatabase.get(ctx).dao().getAlarm(alarmId) }
    }
    val hint = when (alarm?.volumeKeyAction) {
        "DISMISS" -> "Volume key: turn alarm off"
        "SNOOZE" -> "Volume key: snooze ${AlarmService.SNOOZE_MIN} min"
        else -> "Volume key: mute this ring (repeat continues)"
    }
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(alarm?.emoji ?: "⏰", fontSize = 72.sp)
        Text(
            alarm?.title ?: "Alarm",
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center
        )
        Text(formatClock(System.currentTimeMillis()), style = MaterialTheme.typography.displaySmall)
        Spacer(Modifier.height(32.dp))
        Button(onClick = { onAction(AlarmService.ACTION_SNOOZE) }, modifier = Modifier.fillMaxWidth()) {
            Text("Snooze ${AlarmService.SNOOZE_MIN} min")
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { onAction(AlarmService.ACTION_MUTE) }, modifier = Modifier.fillMaxWidth()) {
            Text("Mute (next repeat will ring)")
        }
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = { onAction(AlarmService.ACTION_DISMISS) }) { Text("Turn off alarm") }
        Spacer(Modifier.height(24.dp))
        Text(hint, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
    }
}

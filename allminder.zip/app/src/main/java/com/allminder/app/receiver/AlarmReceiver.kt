package com.allminder.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.allminder.app.data.AppDatabase
import com.allminder.app.scheduler.Scheduler
import com.allminder.app.service.AlarmService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(Scheduler.EXTRA_ID, -1L)
        if (id < 0) return
        val snooze = intent.getBooleanExtra(Scheduler.EXTRA_SNOOZE, false)
        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.get(app).dao()
                val alarm = dao.getAlarm(id)
                if (alarm != null && (alarm.isActive || snooze)) {
                    if (!snooze) {
                        // IMPORTANT: schedule the NEXT repeat first, so muting never affects it.
                        val next = Scheduler.schedule(app, alarm, dao.getTimes(id), Scheduler.holidaySet(dao))
                        if (next == null) dao.setActive(id, false)
                    }
                    ContextCompat.startForegroundService(
                        app, AlarmService.intent(app, id, AlarmService.ACTION_START)
                    )
                }
            } finally {
                pending.finish()
            }
        }
    }
}

package com.allminder.app.ui

import android.Manifest
import android.app.DatePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.allminder.app.data.Alarm
import com.allminder.app.scheduler.Scheduler
import com.allminder.app.util.dateFmt
import com.allminder.app.util.formatNext
import com.allminder.app.util.repeatSummary
import kotlinx.coroutines.delay
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: MainViewModel, onEdit: (Long) -> Unit) {
    val ctx = LocalContext.current
    val alarms by vm.alarms.collectAsStateWithLifecycle()
    val times by vm.times.collectAsStateWithLifecycle()
    val holidays by vm.holidays.collectAsStateWithLifecycle()

    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf("TIME") }
    var sortMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var showHolidays by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = System.currentTimeMillis()
        }
    }

    val holidaySet = remember(holidays) { holidays.map { LocalDate.ofEpochDay(it.epochDay) }.toSet() }
    val nextMap = remember(alarms, times, holidaySet, now) {
        alarms.associate { a ->
            a.id to Scheduler.nextOccurrence(a, times.filter { it.alarmId == a.id }, holidaySet, now)
        }
    }
    val shown = remember(alarms, query, sort, nextMap) {
        alarms.filter { it.title.contains(query, ignoreCase = true) }
            .sortedWith(
                compareByDescending<Alarm> { it.isPinned }.thenComparator { a, b ->
                    when (sort) {
                        "TITLE" -> a.title.compareTo(b.title, ignoreCase = true)
                        "NEW" -> b.id.compareTo(a.id)
                        else -> (nextMap[a.id] ?: Long.MAX_VALUE).compareTo(nextMap[b.id] ?: Long.MAX_VALUE)
                    }
                }
            )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (searching) {
                        TextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            placeholder = { Text("Search alarms") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Text("Allminder")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        searching = !searching
                        if (!searching) query = ""
                    }) {
                        Icon(if (searching) Icons.Filled.Close else Icons.Filled.Search, "Search")
                    }
                    Box {
                        IconButton(onClick = { sortMenu = true }) { Icon(Icons.Filled.FilterList, "Sort") }
                        DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                            DropdownMenuItem(text = { Text("Sort by next alarm") }, onClick = { sort = "TIME"; sortMenu = false })
                            DropdownMenuItem(text = { Text("Sort by title") }, onClick = { sort = "TITLE"; sortMenu = false })
                            DropdownMenuItem(text = { Text("Newest first") }, onClick = { sort = "NEW"; sortMenu = false })
                        }
                    }
                    IconButton(onClick = { onEdit(0L) }) { Icon(Icons.Filled.Add, "Add alarm") }
                    Box {
                        IconButton(onClick = { moreMenu = true }) { Icon(Icons.Filled.MoreVert, "More") }
                        DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                            DropdownMenuItem(text = { Text("Holidays") }, onClick = { showHolidays = true; moreMenu = false })
                        }
                    }
                }
            )
        }
    ) { pad ->
        if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                Text(
                    if (alarms.isEmpty()) "No alarms yet.\nTap + to add one." else "No alarms match your search.",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(pad),
                contentPadding = PaddingValues(12.dp)
            ) {
                items(shown, key = { it.id }) { a ->
                    Card(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .clickable { onEdit(a.id) }
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    (if (a.isPinned) "📌 " else "") + a.emoji + " " + a.title,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(repeatSummary(a), style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    if (a.isActive) formatNext(nextMap[a.id]) else "Off",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Switch(checked = a.isActive, onCheckedChange = { vm.toggle(a.id, it) })
                        }
                    }
                }
            }
        }
    }

    if (showHolidays) {
        AlertDialog(
            onDismissRequest = { showHolidays = false },
            title = { Text("Holidays") },
            text = {
                Column {
                    Text("Alarms with \"Play on holidays\" unchecked stay silent on these dates.", style = MaterialTheme.typography.bodySmall)
                    if (holidays.isEmpty()) {
                        Text("No holidays added.", Modifier.padding(vertical = 12.dp))
                    }
                    holidays.forEach { h ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(LocalDate.ofEpochDay(h.epochDay).format(dateFmt), Modifier.weight(1f))
                            IconButton(onClick = { vm.removeHoliday(h.id) }) { Icon(Icons.Filled.Delete, "Delete") }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val t = LocalDate.now()
                    DatePickerDialog(ctx, { _, y, m, d -> vm.addHoliday(LocalDate.of(y, m + 1, d).toEpochDay()) },
                        t.year, t.monthValue - 1, t.dayOfMonth).show()
                }) { Text("Add date") }
            },
            dismissButton = { TextButton(onClick = { showHolidays = false }) { Text("Close") } }
        )
    }
}

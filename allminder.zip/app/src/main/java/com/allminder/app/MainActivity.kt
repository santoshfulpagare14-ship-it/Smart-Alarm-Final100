package com.allminder.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.allminder.app.ui.EditScreen
import com.allminder.app.ui.HomeScreen
import com.allminder.app.ui.MainViewModel
import com.allminder.app.ui.theme.AllminderTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AllminderTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    // null = home list, 0 = new alarm, >0 = edit that alarm
                    var screen by rememberSaveable { mutableStateOf<Long?>(null) }
                    BackHandler(enabled = screen != null) { screen = null }
                    val s = screen
                    if (s == null) {
                        HomeScreen(vm) { screen = it }
                    } else {
                        EditScreen(vm, s) { screen = null }
                    }
                }
            }
        }
    }
}
